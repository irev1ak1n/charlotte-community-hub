# Charlotte Community Hub

Charlotte Resource Hub is a community website created by the 2025–2026 TSA Webmaster Team at Ballantyne Ridge High School for the Technology Student Association (TSA) Webmaster competition. 
It's intended to help residents of Charlotte to find trusted local resources, programs, events, and support services through a clean, realistic design that looks like a real public website

Student names: 
Illia Reviakin,
Tarun Bhumanapalli, 
Krish Sridhar, 
Revanth Neelakantham,  
Shyam Krishnan, 
Jayanth Tadi
